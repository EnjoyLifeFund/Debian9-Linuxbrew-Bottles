VS_COPY_TO_OUT_DIR
------------------

Sets the ``<CopyToOutputDirectory>`` tag for a source file in a
Visual Studio project file. Valid values are ``Never``, ``Always``
and ``PreserveNewest``.
