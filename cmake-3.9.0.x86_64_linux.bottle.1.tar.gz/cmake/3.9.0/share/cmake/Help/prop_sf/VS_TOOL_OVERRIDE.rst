VS_TOOL_OVERRIDE
----------------

Override the default Visual Studio tool that will be applied to the source file
with a new tool not based on the extension of the file.
